package Exercicio4;

public class Exercicio2 {
    public static void main(String[] args) {
        String[] lista = {"Maça", "Laranja", "Banana", "Pera", "Uva"};
        System.out.println("Lista de compras a fazer:");
        for (String item : lista) {
            System.out.println(item);
        }
    }
}
